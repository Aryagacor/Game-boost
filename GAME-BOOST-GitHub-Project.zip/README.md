# GAME BOOST

Android native Java project. Landscape gaming dashboard, installed-app launcher, control-panel UI, storage picker entry point, WhatsApp developer links, and optional floating overlay.

## Build on GitHub (from Android phone)
1. Create a GitHub repository named `game-boost`.
2. Upload the **contents** of this ZIP to the repository root (keep the `.github` folder).
3. Open **Actions** → **Build GAME BOOST APK** → **Run workflow**.
4. When finished, open the workflow run and download artifact `GAME-BOOST-debug`.
5. Extract the artifact ZIP to get `app-debug.apk`.

## Important Android limitations
- Ordinary non-root apps cannot universally force GPU settings, render scale, internal game resolution, texture quality, or FPS in third-party games. The Control Panel exposes selectable recommendation profiles; apply matching settings inside each game where supported.
- Android does not allow ordinary apps to silently clear another app's private cache or kill all other apps. Cleaner opens the system file picker so users choose files; storage settings are also available.
- Floating overlay requires the user to grant **Display over other apps**.
- CPU frequency and reliable game FPS are not exposed to ordinary third-party apps on many devices. Do not interpret decorative/unsupported metrics as real measurements.
- App requests installed-app visibility for the local game launcher; distribution through app stores may require a narrower package visibility declaration.

No backend or extra server is required. GitHub Actions builds the APK.
