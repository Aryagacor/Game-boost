package com.arya.gameboost;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(8,9,14), PANEL=Color.rgb(20,20,29), RED=Color.rgb(255,42,82), MUTED=Color.rgb(177,169,180);
    LinearLayout root, content;
    TextView status;
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density);}
    GradientDrawable shape(int color,int stroke,int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if(stroke!=0)d.setStroke(dp(1),stroke); return d;
    }
    TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    void pad(View v,int a){v.setPadding(dp(a),dp(a),dp(a),dp(a));}
    TextView button(String label,Runnable action){
        TextView b=text(label,14,Color.WHITE,true); b.setGravity(Gravity.CENTER); b.setBackground(shape(Color.rgb(170,15,48),RED,12));
        b.setPadding(dp(12),dp(10),dp(12),dp(10));
        b.setOnClickListener(v->{b.animate().scaleX(.96f).scaleY(.96f).setDuration(75).withEndAction(()->b.animate().scaleX(1).scaleY(1).setDuration(100)).start(); action.run();});
        return b;
    }
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY); showDashboard();}
    LinearLayout card(String title,String desc){
        LinearLayout c=vertical(); c.setBackground(shape(PANEL,Color.rgb(85,24,43),14)); pad(c,14);
        TextView h=text(title,16,Color.WHITE,true); c.addView(h); TextView d=text(desc,11,MUTED,false); d.setPadding(0,dp(5),0,0);c.addView(d); return c;
    }
    void showDashboard(){
        root=vertical();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout top=horizontal();pad(top,12);
        TextView brand=text("◆  GAME BOOST",22,RED,true);top.addView(brand,new LinearLayout.LayoutParams(0,dp(42),1));
        TextView settings=button("⚙ SETTINGS",()->showSettings());top.addView(settings,lp(130,42));root.addView(top);
        LinearLayout metrics=horizontal();metrics.setPadding(dp(12),0,dp(12),dp(10));
        String[] m={"CPU  •  "+cpuInfo(),"RAM  •  "+ramInfo(),"BATTERY  •  "+batteryInfo(),"DEVICE  •  "+Build.MODEL};
        for(String s:m){LinearLayout c=card(s,"LIVE DEVICE INFORMATION");LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(76),1);p.setMargins(dp(4),0,dp(4),0);metrics.addView(c,p);}
        root.addView(metrics);
        LinearLayout body=horizontal();body.setPadding(dp(12),0,dp(12),dp(12));root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout side=vertical();side.setBackground(shape(Color.rgb(17,13,20),Color.rgb(75,22,39),16));pad(side,12);body.addView(side,lp(190,-1));
        side.addView(text("CONTROL CENTER",13,RED,true)); side.addView(text("Gaming tools & launcher",10,MUTED,false));
        addMenu(side,"⌂  Dashboard",()->showDashboard());addMenu(side,"▣  Control Panel",()->showControl());addMenu(side,"✦  Floating Popup",()->enablePopup());addMenu(side,"♧  Cleaner",()->showCleaner());addMenu(side,"⚙  Settings",()->showSettings());
        LinearLayout main=vertical();main.setPadding(dp(14),0,0,0);body.addView(main,new LinearLayout.LayoutParams(0,-1,1));
        TextView welcome=text("YOUR GAMING COMMAND CENTER",18,Color.WHITE,true);main.addView(welcome);
        TextView sub=text("Pilih game, periksa kondisi perangkat, lalu mulai bermain.",11,MUTED,false);main.addView(sub);
        LinearLayout row=horizontal();row.setPadding(0,dp(12),0,dp(10));main.addView(row);
        LinearLayout boost=card("QUICK BOOST","Tindakan ringan: tutup panel ini dan buka game pilihan. Android membatasi pembersihan proses aplikasi lain.");
        row.addView(boost,new LinearLayout.LayoutParams(0,dp(104),1));
        TextView go=button("OPEN GAME LIST",()->showGames());LinearLayout.LayoutParams gp=lp(160,50);gp.setMargins(dp(10),0,0,0);row.addView(go,gp);
        TextView gamesTitle=text("MY GAMES",15,RED,true);main.addView(gamesTitle);
        TextView gameDesc=text("Game yang terpasang dan menyediakan launcher intent akan muncul di sini.",11,MUTED,false);main.addView(gameDesc);
        LinearLayout gameRow=horizontal();gameRow.setPadding(0,dp(10),0,0);main.addView(gameRow);
        TextView games=button("BROWSE INSTALLED GAMES",()->showGames());gameRow.addView(games,lp(230,44));
        TextView ctl=button("CONTROL PANEL",()->showControl());LinearLayout.LayoutParams cp=lp(180,44);cp.setMargins(dp(10),0,0,0);gameRow.addView(ctl,cp);
        TextView foot=text("GAME BOOST  •  BY ARYA  •  LANDSCAPE EDITION",10,MUTED,false);foot.setGravity(Gravity.RIGHT);main.addView(foot);
    }
    void addMenu(LinearLayout box,String s,Runnable r){TextView t=text(s,13,Color.WHITE,true);t.setPadding(dp(8),dp(12),dp(8),dp(12));box.addView(t);t.setOnClickListener(v->{t.setBackground(shape(Color.rgb(75,15,37),RED,9));r.run();});}
    String cpuInfo(){return "Android";} 
    String ramInfo(){ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);return String.format(Locale.US,"%.1f/%.1f GB",(mi.totalMem-mi.availMem)/1073741824.0,mi.totalMem/1073741824.0);}
    String batteryInfo(){android.content.IntentFilter f=new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED);Intent i=registerReceiver(null,f);if(i==null)return "—";int l=i.getIntExtra("level",-1),s=i.getIntExtra("scale",100);return (l*100/Math.max(1,s))+"%";}
    void addHeader(String title){LinearLayout h=horizontal();TextView back=button("‹ BACK",()->showDashboard());h.addView(back,lp(90,40));TextView t=text(title,20,Color.WHITE,true);t.setPadding(dp(18),0,0,0);h.addView(t);root.addView(h);}
    void page(String title){root=vertical();root.setBackgroundColor(BG);setContentView(root);addHeader(title);content=vertical();content.setPadding(dp(18),dp(12),dp(18),dp(12));root.addView(content,new LinearLayout.LayoutParams(-1,0,1));}
    void showControl(){
        page("CONTROL PANEL");
        LinearLayout tabs=horizontal();content.addView(tabs);
        String[] names={"GAME MODE","GPU SETTINGS","GRAPHICS","RESOLUTION","DISPLAY"};
        for(String n:names){TextView t=button(n,()->{});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),1);p.setMargins(dp(3),0,dp(3),dp(8));tabs.addView(t,p);}
        content.addView(card("GAME MODE","Pilih profil yang akan digunakan sebagai panduan pengaturan game."));
        addChoice("Performance Profile",new String[]{"Performance","Balanced","Battery Saver"});
        content.addView(card("GRAPHICS PROFILE","Preset rekomendasi. Pengaturan ini tidak memaksa perubahan konfigurasi internal game pihak ketiga."));
        addChoice("Graphics Quality",new String[]{"POTATO / VERY LOW","LOW","MEDIUM","HIGH","ULTRA"});
        addChoice("Texture Quality",new String[]{"Very Low","Low","Medium","High"});
        addChoice("Shadow Quality",new String[]{"Off (jika didukung game)","Low","Medium","High"});
        addChoice("Anti-Aliasing",new String[]{"Off","2x","4x","8x"});
        addChoice("Render Scale",new String[]{"50%","60%","75%","100%"});
        addChoice("Resolution guide",new String[]{"480p","540p","720p","900p","1080p"});
        TextView note=text("Catatan: Android non-root umumnya tidak dapat memaksa resolusi, texture, shader, atau GPU setting game lain. Pilihan di sini adalah profil/referensi untuk pengaturan dalam game.",10,MUTED,false);note.setPadding(0,dp(10),0,0);content.addView(note);
    }
    void addChoice(String label,String[] options){
        TextView l=text(label,13,RED,true);l.setPadding(0,dp(10),0,dp(4));content.addView(l);
        Spinner sp=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,options);sp.setAdapter(a);content.addView(sp,lp(-1,42));
    }
    void showCleaner(){
        page("JUNK CLEANER");
        content.addView(card("STORAGE CLEANER","Temukan file besar dan file yang dapat dipilih pengguna untuk dihapus."));
        TextView scan=button("SCAN DEVICE STORAGE",()->{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
            try{startActivityForResult(i,44);}catch(Exception e){toast("File picker tidak tersedia");}
        });scan.setPadding(dp(20),dp(15),dp(20),dp(15));content.addView(scan);
        content.addView(card("RAM MONITOR","RAM tersedia: "+ramInfo()));
        content.addView(card("CLEANING LIMITATIONS","Aplikasi biasa tidak dapat menghapus cache aplikasi lain secara diam-diam. Pilih file sendiri melalui pemilih file Android."));
        content.addView(button("OPEN ANDROID STORAGE SETTINGS",()->startActivity(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))));
    }
    void showGames(){
        page("INSTALLED GAMES");
        PackageManager pm=getPackageManager();List<android.content.pm.ApplicationInfo> apps=pm.getInstalledApplications(0);
        ScrollView sc=new ScrollView(this);content.addView(sc);LinearLayout list=vertical();sc.addView(list);
        int count=0;
        for(ApplicationInfo ai:apps){
            Intent launch=pm.getLaunchIntentForPackage(ai.packageName);
            if(launch==null)continue;
            String label=pm.getApplicationLabel(ai).toString();
            LinearLayout item=horizontal();item.setBackground(shape(PANEL,Color.rgb(75,25,42),10));item.setPadding(dp(10),dp(8),dp(10),dp(8));
            try{ImageView icon=new ImageView(this);icon.setImageDrawable(pm.getApplicationIcon(ai));item.addView(icon,lp(42,42));}catch(Exception ignored){}
            TextView name=text(label,14,Color.WHITE,true);name.setPadding(dp(10),0,0,0);item.addView(name,new LinearLayout.LayoutParams(0,dp(48),1));
            item.addView(button("PLAY",()->{try{startActivity(launch);}catch(Exception e){toast("Game tidak dapat dibuka");}}),lp(90,40));
            LinearLayout.LayoutParams p=lp(-1,58);p.setMargins(0,0,0,dp(6));list.addView(item,p);count++;
        }
        if(count==0)list.addView(text("Tidak ditemukan aplikasi yang bisa dibuka.",13,MUTED,false));
    }
    void showSettings(){
        page("SETTINGS");
        content.addView(card("HUB DEV JIKA ADA YANG MASALAH","Hubungi developer GAME BOOST melalui WhatsApp."));
        content.addView(button("HUB DEV  •  WHATSAPP",()->openWhatsApp("Hallo Developer GAME BOOST, saya mengalami masalah pada aplikasi.")));
        content.addView(card("SARAN FITUR TAMBAHAN HUB DEV","Kirim ide dan permintaan fitur baru kepada developer."));
        content.addView(button("KIRIM SARAN FITUR",()->openWhatsApp("Hallo Developer GAME BOOST, saya ingin memberikan saran fitur tambahan: ")));
        content.addView(card("APP INFORMATION","GAME BOOST • BY ARYA\\nVersion 1.0 • Landscape"));
        content.addView(button("FLOATING POPUP PERMISSION",()->enablePopup()));
    }
    void openWhatsApp(String msg){
        String url="https://wa.me/6285928149092?text="+Uri.encode(msg);
        try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){toast("WhatsApp atau browser tidak tersedia");}
    }
    void enablePopup(){
        if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);toast("Aktifkan izin tampil di atas aplikasi lain, lalu kembali.");
        }else{startService(new Intent(this,FloatingService.class));toast("Floating popup aktif");}
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
