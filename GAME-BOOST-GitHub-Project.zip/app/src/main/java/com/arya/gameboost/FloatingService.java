package com.arya.gameboost;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;

public class FloatingService extends Service {
    WindowManager wm; View panel; boolean expanded=false;
    int dp(float v){return (int)(getResources().getDisplayMetrics().density*v);}
    GradientDrawable bg(int c){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(14));d.setStroke(dp(1),Color.rgb(255,45,85));return d;}
    @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);showBubble();}
    TextView btn(String s){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(12);t.setGravity(Gravity.CENTER);t.setPadding(dp(10),dp(9),dp(10),dp(9));t.setBackground(bg(Color.rgb(32,12,22)));return t;}
    void showBubble(){
        if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){stopSelf();return;}
        TextView bubble=btn("GB");bubble.setTextSize(16);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(54),dp(54),type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL;p.x=dp(8);
        bubble.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;public boolean onTouch(View v,android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE){p.x=ox+(int)(sx-e.getRawX());p.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(bubble,p);return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){if(Math.abs(e.getRawX()-sx)<12&&Math.abs(e.getRawY()-sy)<12)toggle();return true;}return true;}});
        panel=bubble;wm.addView(panel,p);
    }
    void toggle(){
        if(expanded){wm.removeView(panel);expanded=false;showBubble();return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(10),dp(10),dp(10),dp(10));box.setBackground(bg(Color.rgb(12,10,17)));
        TextView title=btn("GAME BOOST  •  TOOLS");box.addView(title);
        String[] items={"QUICK CLEAN","RAM INFO","TEMPERATURE INFO","CLOSE"};
        for(String s:items){TextView t=btn(s);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(42));lp.topMargin=dp(5);box.addView(t,lp);
            t.setOnClickListener(v->{if(s.equals("CLOSE")){stopSelf();}else if(s.equals("QUICK CLEAN")){Toast.makeText(this,"Gunakan Cleaner untuk memilih file yang ingin dihapus.",Toast.LENGTH_LONG).show();}else if(s.equals("RAM INFO")){ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);Toast.makeText(this,"RAM tersedia: "+(mi.availMem/1048576)+" MB",Toast.LENGTH_LONG).show();}else Toast.makeText(this,"Informasi suhu tersedia sesuai sensor perangkat.",Toast.LENGTH_LONG).show();});
        }
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(220),-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL;p.x=dp(8);
        wm.removeView(panel);panel=box;wm.addView(panel,p);expanded=true;
    }
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){if(panel!=null&&panel.isAttachedToWindow())wm.removeView(panel);super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
